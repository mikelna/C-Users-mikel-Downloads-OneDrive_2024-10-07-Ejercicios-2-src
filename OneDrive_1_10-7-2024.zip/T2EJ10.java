import java.util.Scanner;

public class T2EJ10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		double precio;
		double precioFinal;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Introduce Precio:");
		precio = sc.nextDouble();
		
		
		precioFinal = precio - (precio*0.1);
		if (precio > 1000){
			System.out.println(precioFinal);
		}else{
			System.out.println(precio);
		}
	}

}
