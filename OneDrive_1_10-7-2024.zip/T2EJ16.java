import java.util.Scanner;

public class T2EJ16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Variables
		double cantidad;
		int precioUnidad = 13;
		double costeTotal;
		double resultado;
		
		//Leer cantidad comprada
		System.out.println("Cantidad comprada");
		Scanner sc = new Scanner(System.in);
		cantidad = sc.nextDouble();
		
		costeTotal = (cantidad*precioUnidad);
		resultado = (costeTotal - (costeTotal * 0.15));
		if (costeTotal < 70){
			System.out.print(resultado);
		}else{
			System.out.println(costeTotal);
		}
		
	}

}
