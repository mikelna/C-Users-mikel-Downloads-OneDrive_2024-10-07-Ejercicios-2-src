import java.util.Scanner;

public class T2EJ11 {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//Variable
		char letra;
		//leer variable
		Scanner sc = new Scanner(System.in);
		
		
		
		System.out.println();
		
		letra = (char) sc.nextLong(); 
		
		//Letra es igual
		switch (letra){
		
		case 'a':
			System.out.print("vocal");
		break;
		case 'e':
			System.out.print("vocal");
		break;
		case 'i':
			System.out.print("vocal");
		break;
		case 'o':
			System.out.println("vocal");
		break;
		case 'u':
			System.out.println("vocal");
		break;
		default:
			System.out.println("Consonante");
		}
		
	}

}
